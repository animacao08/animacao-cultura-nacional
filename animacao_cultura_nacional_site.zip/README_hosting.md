ANIMAÇÃO CULTURA NACIONAL - PASSO A PASSO PARA COLOCAR O SITE NO AR

1) O que está neste pacote
- index.html (home com capa e teaser)
- login.html (tela de acesso)
- visitante.html (formulário de envio de comprovante)
- upload.php (script que salva comprovantes e envia notificação por e-mail)
- thankyou.html (página de obrigado)
- style.css, script.js
- admin_notes.txt (senhas iniciais e instruções rápidas)
- /comprovantes (pasta onde os comprovantes serão salvos - será criada automaticamente no servidor)

2) Requisitos do servidor
- Hospedagem com suporte a PHP (PHP 7+ recomendado) para o upload funcionar.
- Espaço para armazenar comprovantes.
- Um endereço de e-mail para receber notificações (configure em upload.php).
- Opcional: certificado SSL (https) recomendado para segurança.

3) Passo a passo rápido (cPanel / hospedagem compartilhada)
- Faça upload dos arquivos para a pasta public_html (ou a pasta do seu site).
- Crie a pasta 'comprovantes' no mesmo diretório e ajuste permissões (chmod 755 ou 775). Se o upload falhar, tente 775.
- Edite upload.php e substitua(SEU_EMAIL_AQUI@example.com) pelo seu e-mail real.
- Teste abrindo https://seusite.com/index.html e envie um comprovante pelo formulário.
- Verifique se o arquivo aparece em comprovantes/ e se você recebeu o e-mail.

4) Testar localmente (opção de desenvolvedor)
- Instale PHP localmente e rode: php -S localhost:8000
- Acesse http://localhost:8000 no navegador e teste o formulário (o envio vai salvar os arquivos localmente).

5) Segurança e melhorias recomendadas
- Troque as senhas iniciais em admin_notes.txt e script.js assim que publicar.
- Proteja a pasta comprovantes com .htaccess para impedir listagens (ou mova para fora da pasta pública).
- Para enviar e-mails com anexo ou usar SMTP autenticado, configure PHPMailer ou similar.
- Para automatizar liberação de acesso, crie painel administrativo que verifique comprovantes e associe e-mails a contas.

6) Publicação via GitHub Pages (alerta)
- GitHub Pages não suporta PHP. Se quiser hospedar sem backend, use Netlify/ Vercel com funções serverless para processar uploads, ou um host com PHP.

7) Precisa que eu hospede ou te ajude a publicar?
- Posso te orientar passo a passo para HostGator, cPanel, Netlify (funções) ou Vercel. Me diga qual provedor pretende usar.
