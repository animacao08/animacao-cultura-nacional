<?php
// upload.php - salva comprovante em /comprovantes e envia e-mail com anexo
// ATENÇÃO: configure corretamente o servidor de e-mail (php mail ou SMTP) no seu host.
// Crie a pasta 'comprovantes' com permissão de escrita pelo servidor (chmod 755/775 conforme o host).

$config_email = 'SEU_EMAIL_AQUI@example.com'; // <- substitua pelo seu e-mail
$admin_password = 'cristiomar_admin'; // senha de admin (por enquanto apenas no admin_notes.txt)

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = isset($_POST['nome']) ? substr(trim($_POST['nome']),0,200) : 'Sem nome';
    $email = isset($_POST['email']) ? substr(trim($_POST['email']),0,200) : 'Sem email';
    if (!isset($_FILES['comprovante'])) {
        die('Nenhum arquivo enviado.');
    }
    $file = $_FILES['comprovante'];
    // Criar pasta se não existir
    $uploadDir = __DIR__ . '/comprovantes';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }
    $filename = basename($file['name']);
    // Para segurança, prefixamos com timestamp
    $target = $uploadDir . '/' . time() . '_' . preg_replace('/[^A-Za-z0-9._-]/', '_', $filename);
    if (move_uploaded_file($file['tmp_name'], $target)) {
        // Enviar email simples para notificar (anexo pode exigir configuração adicional)
        $subject = 'Novo comprovante recebido - Animação Cultura Nacional';
        $message = "Nome: $nome\nEmail: $email\nArquivo: $target";
        // Tente enviar e-mail (funciona se o servidor estiver configurado para isso)
        @mail($config_email, $subject, $message);
        // Redireciona para página de agradecimento
        header('Location: thankyou.html');
        exit;
    } else {
        echo 'Erro ao salvar o arquivo.';
    }
} else {
    echo 'Método inválido.';
}
?>